# CS839 DataSciences
project page for CS839 Data Sciences (2019 Fall)

## members: 
* Jing Liu
* Zhihan Guo
* Yiwu Zhong

 [Link](https://github.com/ScarletGuo/CS839-DataSciences/tree/master/data/all) to a directory that stores the 300+ documents.

 [Link](https://github.com/ScarletGuo/CS839-DataSciences/tree/master/data/labeled/train) to all documents in set I.

 [Link](https://github.com/ScarletGuo/CS839-DataSciences/tree/master/data/labeled/test) to all documents in set J.

 [Link](https://github.com/ScarletGuo/CS839-DataSciences) to all codes.

 Link ??? to a compressed file that stores all of the above directories.

 [Link](https://github.com/ScarletGuo/CS839-DataSciences/tree/master/docs) to the pdf report document.

