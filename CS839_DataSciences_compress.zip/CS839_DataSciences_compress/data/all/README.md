# CS839 DataSciences
project page for CS839 Data Sciences (2019 Fall)

## members: 
* Jing Liu
* Zhihan Guo
* Yiwu Zhong

Person names are marked up in the documents using <>person_name</> tags.


