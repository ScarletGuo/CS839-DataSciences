# CS839 Data Sciences
project page for CS839 Data Sciences (2019 Fall)

## members: 
* Jing Liu
* Zhihan Guo
* Yiwu Zhong

## Project
